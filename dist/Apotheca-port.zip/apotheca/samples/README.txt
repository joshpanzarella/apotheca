Put .wav files here. Each can go on a drum lane: DEVICE screen of a drum track.
Up to ten seconds of each is used.
